/* null version of <arpa/inet.h> - <sys/socket.h> has everything */

/* arch-tag: 13c7a7f7-40d0-49e8-bdfb-6dcf2f3a7340
   (do not change this comment) */
