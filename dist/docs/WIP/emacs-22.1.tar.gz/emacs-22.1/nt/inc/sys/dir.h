/*
 * map sys\dir.h to ..\..\..\src\ndir.h
 */

#include "..\..\..\src\ndir.h"

/* arch-tag: 090c9091-3b16-429b-9c40-8aecce1162be
   (do not change this comment) */
