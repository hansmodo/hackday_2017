/*
 * sys\ioctl.h doesn't exist on NT...rather than including it conditionally
 * in many of the source files, we just extend the include path so that the
 * compiler will pick this up empty header instead.
 */

/* arch-tag: c6e9015a-930a-4ad3-b368-ac32f84475d7
   (do not change this comment) */
