/* Emacs ioctl emulation for VMS */

/* arch-tag: 48595931-af6e-407d-95c7-484059087767
   (do not change this comment) */
