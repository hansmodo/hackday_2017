/* config.h should include this file for version 1 of Alliant's
   operating system.  */

/* The following line tells the configuration script what sort of
   operating system this machine is likely to run.
   USUAL-OPSYS="bsd4-2"  */

#define ALLIANT_1
#include "alliant.h"

/* arch-tag: 516688f9-4b94-4356-9bf0-92b2d72e664e
   (do not change this comment) */
