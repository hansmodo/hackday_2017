/* I don't care if this doesn't do more than including bsd4-3.h;
   Mach is not bsd4-3 and the moment you forget it chances are that
   you're in deep shit.  */

#include "bsd4-3.h"

/* arch-tag: 7f7f00f6-ae34-413e-9e6a-1d3b3e3d07e8
   (do not change this comment) */
