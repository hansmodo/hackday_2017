#include "bsd4-3.h"

/* Inhibit using -X, which is the default.  */
#define LD_SWITCH_SYSTEM

/* arch-tag: 08941c4f-d0b6-4ad6-b7e3-7e7fe76c0e94
   (do not change this comment) */
